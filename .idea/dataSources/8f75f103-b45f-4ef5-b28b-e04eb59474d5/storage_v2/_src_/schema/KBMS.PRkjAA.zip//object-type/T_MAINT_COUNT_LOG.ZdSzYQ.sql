create TYPE "T_MAINT_COUNT_LOG"                                                                          AS OBJECT
(
  MAINT_NM  VARCHAR2(200), --对外维护名称
  SB_COUNT    VARCHAR2(200), --已提交
  N_SB_COUNT  VARCHAR2(200), --未提交
  T_COUNT   VARCHAR2(200) --总数
)
/

