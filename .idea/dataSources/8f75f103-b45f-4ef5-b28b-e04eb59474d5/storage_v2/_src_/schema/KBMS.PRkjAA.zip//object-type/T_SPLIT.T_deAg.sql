create TYPE "T_SPLIT"                                                                          AS OBJECT
(
  ID      VARCHAR2(200),
  CONTENT VARCHAR2(200)
)
/

