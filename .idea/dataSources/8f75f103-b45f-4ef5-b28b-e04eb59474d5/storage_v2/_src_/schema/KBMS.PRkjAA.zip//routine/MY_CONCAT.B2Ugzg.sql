create FUNCTION my_concat(P1 VARCHAR2) RETURN clob AGGREGATE USING zh_concat_im;
/

