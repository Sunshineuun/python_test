create TYPE "T_MAINT_LOG"                                                                          AS OBJECT
(
  MAINT_NM  VARCHAR2(200), --对外维护名称
  ADD_SB    VARCHAR2(200), --新增已提交
  SB_EDIT   VARCHAR2(200), --已提交编辑
  SB_DEL    VARCHAR2(200), --已提交删除
  T_COUNT   VARCHAR2(200), --总数
  RULE      VARCHAR2(200)  --规则ID
)
/

