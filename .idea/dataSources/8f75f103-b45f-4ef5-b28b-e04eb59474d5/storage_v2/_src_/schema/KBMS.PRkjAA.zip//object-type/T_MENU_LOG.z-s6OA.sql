create TYPE "T_MENU_LOG"                                                                          AS OBJECT
(
  MNU_NM    VARCHAR2(200), --菜单名称
  MOD_NM    VARCHAR2(200), --模块名称
  ADD_SB    VARCHAR2(200), --新增已提交
  ADD_N_SB  VARCHAR2(200), --新增未提交
  MAPPING   VARCHAR2(200), --映射数
  SB_EDIT_B VARCHAR2(200), --已提交编辑B
  SB_EDIT_C VARCHAR2(200), --已提交编辑B
  SB_DEL    VARCHAR2(200), --已提交删除
  N_SB_DEL  VARCHAR2(200), --未提交删除
  T_COUNT   VARCHAR2(200) --总数
)
/

