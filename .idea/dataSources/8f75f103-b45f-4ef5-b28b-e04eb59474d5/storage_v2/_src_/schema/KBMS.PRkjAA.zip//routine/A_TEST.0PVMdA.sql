create procedure a_test(mycol in varchar2,
mytab in varchar2,
mywhere in varchar2,
mysql out varchar2,
my_cursor2 out sys_refcursor) as
my_cursor sys_refcursor;
mysql99 clob;
begin
mysql := 'select (''select ''''''||replace(wm_concat2(to_char(' || mycol ||
')),'','','''''','''''')||'''''' from dual'') from ' || mytab||' where 1=1 '||mywhere;
OPEN my_cursor FOR mysql;
FETCH my_cursor into mysql99;
OPEN my_cursor2 FOR mysql99;
end;
/

